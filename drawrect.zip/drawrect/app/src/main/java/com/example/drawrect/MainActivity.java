package com.example.drawrect;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    String s="";
    class MyVeiw extends View{
        Paint p;
        float x1,y1,x2,y2;

        MyVeiw(Context c){
            super(c);
            p = new Paint();
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            p.setStyle(Paint.Style.STROKE);
            //p.setStrokeWidth(8);
            p.setColor(Color.RED);
            canvas.drawText(s,20,40,p);
        }

        @Override
        public boolean onTouchEvent(MotionEvent event) {
            int ind = event.getAction() >> 8;  //상위 8비트, 손가락 번호
            int act = event.getAction() & 0xff; //하위 8비트, 액션

            switch ( act ){
                case MotionEvent.ACTION_DOWN:
                    s = String.format("Down x=%3.0f y=%3.0f index=%d\n", event.getX(ind),event.getY(ind),ind);
                    invalidate();
                    break;

                case MotionEvent.ACTION_UP:
                    s = String.format("Up x=%3.0f y=%3.0f index=%d\n", event.getX(ind),event.getY(ind),ind);
                    invalidate();
                    break;

                case MotionEvent.ACTION_POINTER_DOWN:
                    s = String.format("Pointer-Down x=%3.0f y=%3.0f index=%d\n", event.getX(ind),event.getY(ind),ind);
                    invalidate();
                    break;

                case MotionEvent.ACTION_POINTER_UP:
                    s = String.format("Pointer-Up x=%3.0f y=%3.0f index=%d\n", event.getX(ind),event.getY(ind),ind);
                    invalidate();
                    break;
            }
            return true;
        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        MyVeiw mv;
        mv = new MyVeiw(this);
        setContentView(mv);
    }
}