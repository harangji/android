package com.example.grid;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ListView;

public class MainActivity extends AppCompatActivity {

    ListView lv;
    GridView gv;
    String jang[] = {"이순신","권율","강감찬","김유신"};
    int image[] = {R.drawable.red,R.drawable.blue,R.drawable.green,R.drawable.yellow,R.drawable.cyan};
    ArrayAdapter<String> adap;
    MyAdapter myadap;

    class MyAdapter extends BaseAdapter {
        Context con;

        MyAdapter(Context c){
            con = c;
        }

        @Override
        public int getCount() {
            return 20;
        }

        @Override
        public Object getItem(int i) {
            ImageView iv;
            iv = new ImageView(con);
            iv.setImageResource(image[i%5]);
            return iv;
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            ImageView iv;
            iv = new ImageView(con);
            iv.setImageResource(image[i%5]);
            return (View) iv;
        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        lv = (ListView) findViewById(R.id.mylist);
        adap = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_list_item_1,jang);
        lv.setAdapter(adap);

        gv = (GridView) findViewById(R.id.grid);
        myadap = new MyAdapter(this);
        gv.setAdapter(myadap);
    }
}