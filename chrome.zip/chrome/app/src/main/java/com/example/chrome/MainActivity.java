package com.example.chrome;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    EditText url;
    Button go,back,forward;
    WebView wv;
    View.OnClickListener cl;
View.OnKeyListener kl;
    class MyClient extends WebViewClient{
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {



            return super.shouldOverrideUrlLoading(view, request);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        url = (EditText) findViewById(R.id.text);
        go = (Button) findViewById(R.id.go);
        back = (Button) findViewById(R.id.back);
        forward = (Button) findViewById(R.id.forward);
        wv = (WebView) findViewById(R.id.web);

        wv.setWebViewClient(new MyClient());

        WebSettings ws;
        ws = wv.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setBuiltInZoomControls(true);

        cl = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                switch (view.getId()){
                    case R.id.go:
                        wv.loadUrl(url.getText().toString());
                        break;

                    case R.id.back:
                        wv.goBack();
                        break;

                    case R.id.forward:
                        wv.goForward();
                        break;
                }
            }
        };
        go.setOnClickListener(cl);
        back.setOnClickListener(cl);
        forward.setOnClickListener(cl);

        kl = new View.OnKeyListener() {
            @Override
            public boolean onKey(View view, int i, KeyEvent keyEvent) {
                if ( i == keyEvent.KEYCODE_ENTER){
                    wv.loadUrl(url.getText().toString());
                }
                return false;
            }
        };
        url.setOnKeyListener(kl);
    }
}