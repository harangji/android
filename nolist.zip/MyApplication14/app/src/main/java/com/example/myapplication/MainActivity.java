package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    ListView lv;
    String jang[] = {"이순신","권율","김유신","강감찬","을지문덕"};
    ArrayAdapter<String> adap;

    AdapterView.OnItemClickListener icl;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        lv =(ListView) findViewById(R.id.mylist);
        //adap = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,jang);
        adap = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_single_choice,jang);  // 라디오버튼같이
        lv.setChoiceMode(ListView.CHOICE_MODE_SINGLE); // 라디오버튼같이 세트

        lv.setAdapter(adap);

        icl = new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Toast.makeText(getApplicationContext(), "index= "+ i + " 장군이름= " +jang[i], Toast.LENGTH_SHORT).show();
            }
        };
        lv.setOnItemClickListener(icl);
    }
}