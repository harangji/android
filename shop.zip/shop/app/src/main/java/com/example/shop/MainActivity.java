package com.example.shop;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Adapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ListView lv;
    int total=0;

    ArrayList<MyItem> product;
    MyAdapter myadap;


    class MyItem{
        int icon;
        String comment;
        int pr;
        float rate;
        MyItem(int a,String b, int c, float d){
            icon = a;
            comment = b;
            pr = c;
            rate = d;
        }
    }

    class MyAdapter extends BaseAdapter{
        Context con;



        MyAdapter(Context c){
            con = c;
        }

        @Override
        public int getCount() {
            return product.size();
        }

        @Override
        public Object getItem(int i) {
            return product.get(i);
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            if(view == null){
                view = ((LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE)).inflate(R.layout.myitem,viewGroup,false);
            }
            ImageView iv;
            TextView tv;
            EditText ed;
            RatingBar rb;
            Button buy;
            View.OnClickListener cl;
            iv = (ImageView) view.findViewById(R.id.image);
            iv.setImageResource(product.get(i).icon);
            tv = (TextView) view.findViewById(R.id.text);
            tv.setText(product.get(i).comment);
            ed = (EditText) view.findViewById(R.id.price);
            ed.setText(product.get(i).pr+"");
            rb=(RatingBar) view.findViewById(R.id.rating);
            rb.setRating(product.get(i).rate);
            buy = (Button) view.findViewById(R.id.buy);
            cl = new View.OnClickListener(){
                @Override
                public void onClick(View view) {
                    total = total + product.get(i).pr;
                    Toast.makeText(getApplicationContext(),product.get(i).comment.substring(0,10)+" 가격= "+product.get(i).pr+" 총합="+total,Toast.LENGTH_LONG).show();
                }
            };
            buy.setOnClickListener(cl);
            return view;
        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        product = new ArrayList<MyItem>(); //메모리 확보
        MyItem mi;

        mi = new MyItem(R.drawable.tv,"LG SIGNATURE\n OLED 8K ",47000000,4.5f);
        product.add(mi);
        mi = new MyItem(R.drawable.drum,"LG SIGNATURE 세탁기",3790000,4.0f);
        product.add(mi);
        mi = new MyItem(R.drawable.ice,"LG SIGNATURE 냉장고",6700000,3.5f);
        product.add(mi);

        lv = (ListView) findViewById(R.id.mylist);
        myadap = new MyAdapter(this);
        lv.setAdapter(myadap);
    }
}