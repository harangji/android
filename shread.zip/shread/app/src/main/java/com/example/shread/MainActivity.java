package com.example.shread;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.SystemClock;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    EditText ha;
    Button start1;
    View.OnClickListener cl;
    int cnt1 = 0;
    MyHandler mh;

    class MyHandler extends Handler{
        @Override
        public void handleMessage(@NonNull Message msg) {
            super.handleMessage(msg);
            if (msg.what == 0){
                ha.setText("counter1= "+cnt1);
                cnt1++;
            }else if(msg.what == 1){
                ha.setText("counter2= "+cnt1);
                cnt1++;
            }else if(msg.what == 2){
                ha.setText("counter3= "+cnt1);
                cnt1++;
            }
        }
    }

    class MyThread extends Thread{
        @Override
        public void run() {
            super.run();
            cnt1 = 0;
            for(int i=0; i<5; i++) {
//                ha.setText("counter1= "+cnt1);
//                cnt1++;
                mh.sendEmptyMessage(0);
                SystemClock.sleep(1000);
            }
        }
    }

    class MyThread1 extends Thread{
        @Override
        public void run() {
            super.run();
            for(int i=0; i<10; i++) {
                mh.sendEmptyMessage(1);
                SystemClock.sleep(1010);
            }
        }
    }

    class MyThread2 extends Thread{
        @Override
        public void run() {
            super.run();
            for(int i=0; i<15; i++) {
                mh.sendEmptyMessage(2);
                SystemClock.sleep(1020);
            }
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mh = new MyHandler();

        ha = (EditText) findViewById(R.id.half);
        start1 = (Button) findViewById(R.id.start1);
        cl = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                switch ( view.getId()){
                    case R.id.start1:
                        MyThread mt;
                        mt = new MyThread();
                        mt.start();

                        MyThread1 mt1;
                        mt1 = new MyThread1();
                        mt1.start();

                        MyThread2 mt2;
                        mt2 = new MyThread2();
                        mt2.start();
                        break;
                }
            }
        };
        start1.setOnClickListener(cl);
    }
}