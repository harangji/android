package com.example.myapplication;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.Nullable;

public class myplus extends Activity {

    TextView prsult;
    Button pexit, pexit1;
    View.OnClickListener cl;
    Intent i;
    Integer a,b,c;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.myplus);

        prsult = (TextView) findViewById(R.id.plusresult);
        pexit = (Button) findViewById(R.id.plusexit);
        pexit1 = (Button) findViewById(R.id.plusexit1);

        i = getIntent();
        a = Integer.parseInt(i.getStringExtra("n1"));
        b = Integer.parseInt(i.getStringExtra("n2"));
        c = a+b;
        prsult.setText("덧셉="+c);

        cl = new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                switch (view.getId()){
                    case R.id.plusexit:
                        c = a*b;
                    i = new Intent();
                    i.putExtra("nyr",c);
                    setResult(100, i);
                    finish();
                    break;
                    case R.id.plusexit1:
                        c = a/b;
                        i = new Intent();
                        i.putExtra("nyr",c);
                        setResult(101, i);
                        finish();
                        break;
                }
            }
        };
        pexit.setOnClickListener(cl);
        pexit1.setOnClickListener(cl);
    }
}
