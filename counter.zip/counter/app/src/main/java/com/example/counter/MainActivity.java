package com.example.counter;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.SystemClock;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;

public class MainActivity extends AppCompatActivity {

    EditText t1, t2, t3;
    Button start1, stop1, start2, stop2, start3, stop3, start4, stop4;

    View.OnClickListener cl;
    int cnt1=0, cnt2=0, cnt3=0, cnt4;
    boolean c1 = true, c2 = true, c3 = true, c4 = true;
    ProgressBar pb;
    MyHandler hand;

    class MyHandler extends Handler{
        @Override
        public void handleMessage(@NonNull Message msg) {
            super.handleMessage(msg);
            if ( msg.what == 10){
                t1.setText("counter1 = "+cnt1);
            }else if( msg.what == 20){
                t2.setText("counter2 = "+cnt1);
            }else if( msg.what == 30){
                if(c3==true){
                cnt1++;
                t3.setText("counter3 = "+cnt1);
                hand.sendEmptyMessageDelayed(30,2000);
                }
            }else if( msg.what == 40){
                if(c4==true){
                    if(pb.getProgress()==100){
                        pb.setProgress(0);
                    }
                pb.setProgress(pb.getProgress()+10);
                hand.sendEmptyMessageDelayed(40,600);
                }
            }
        }
    }

    class MyCounter1 extends Thread{
        @Override
        public void run() {
            super.run();
            while(c1==true){
                cnt1++;
                SystemClock.sleep(500);
                hand.sendEmptyMessage(10);
            }
        }
    }

    class MyCounter2 extends Thread{
        @Override
        public void run() {
            super.run();
            while(c2==true){
                cnt1++;
                SystemClock.sleep(1000);
                hand.sendEmptyMessage(20);
            }
        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        hand = new MyHandler();

        t1 = (EditText) findViewById(R.id.timer1);
        t2 = (EditText) findViewById(R.id.timer2);
        t3 = (EditText) findViewById(R.id.timer3);
        start1 = (Button) findViewById(R.id.start1);
        start2 = (Button) findViewById(R.id.start2);
        start3 = (Button) findViewById(R.id.start3);
        start4 = (Button) findViewById(R.id.start4);
        stop1 = (Button) findViewById(R.id.stop1);
        stop2 = (Button) findViewById(R.id.stop2);
        stop3 = (Button) findViewById(R.id.stop3);
        stop4 = (Button) findViewById(R.id.stop4);

        pb = (ProgressBar) findViewById(R.id.progress);

        cl = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                switch (view.getId()){
                    case R.id.start1:
                        c1 = true;
                        MyCounter1 mc1;
                        mc1 = new MyCounter1();
                        mc1.start();
                        break;
                    case R.id.stop1:
                        c1 = false;
                        break;

                    case R.id.start2:
                        c2 = true;
                        MyCounter2 mc2;
                        mc2 = new MyCounter2();
                        mc2.start();
                        break;
                    case R.id.stop2:
                        c2 = false;
                        break;

                    case R.id.start3:
                        c3=true;
                        hand.sendEmptyMessage(30);
                        break;
                    case R.id.stop3:
                        c3 = false;
                        break;

                    case R.id.start4:
                        c4=true;
                        hand.sendEmptyMessage(40);
                        break;
                    case R.id.stop4:
                        c4 = false;
                        pb.setProgress(0);
                        break;
                }
            }
        };
        start1.setOnClickListener(cl);
        start2.setOnClickListener(cl);
        start3.setOnClickListener(cl);
        start4.setOnClickListener(cl);
        stop1.setOnClickListener(cl);
        stop2.setOnClickListener(cl);
        stop3.setOnClickListener(cl);
        stop4.setOnClickListener(cl);

    }
}