package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ListView lv;
    String jang[] = {"이순신","권율","김유신","강감찬","을지문덕"}; // 배열
    ArrayAdapter<String> adap;

    ArrayList<String> fruits;  //리스트
    EditText te;
    Button ins, del;

    int sel = 0;
    AdapterView.OnItemClickListener icl;
    View.OnClickListener cl;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        fruits = new ArrayList<String>();

        fruits.add("딸기");
        fruits.add("비나나");
        fruits.add("수박");
        fruits.add("참외");

        lv =(ListView) findViewById(R.id.mylist);
        //adap = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,jang);
        //adap = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_single_choice,jang);  // 라디오버튼같이
        adap = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_single_choice,fruits);
        lv.setChoiceMode(ListView.CHOICE_MODE_SINGLE); // 라디오버튼같이 세트

        lv.setAdapter(adap);

        te = (EditText) findViewById(R.id.text);
        ins = (Button) findViewById(R.id.insert);
        del = (Button) findViewById(R.id.delete);



        icl = new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                //Toast.makeText(getApplicationContext(), "index= "+ i + " 장군이름= " +jang[i], Toast.LENGTH_SHORT).show();
                sel = i;
                Toast.makeText(getApplicationContext(), "index= "+ i + " 과일이름= " +fruits.get(i), Toast.LENGTH_SHORT).show();
            }
        };
        lv.setOnItemClickListener(icl);

        cl =new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                switch (view.getId()){
                    case R.id.insert:
                        fruits.add(te.getText().toString());
                        adap.notifyDataSetChanged(); //항목 바꼈다 수정해라 아그야
                        break;
                    case R.id.delete:
                        fruits.remove(sel);
                        adap.notifyDataSetChanged();
                        lv.clearChoices();
                        break;
                }
            }
        };
        ins.setOnClickListener(cl);
        del.setOnClickListener(cl);
    }
}