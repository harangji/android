package com.example.pinch;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Matrix;
import android.os.Bundle;
import android.view.MotionEvent;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    ImageView iv;
    TextView tv;
    float d1, d2, ratio;
    Matrix m;
    String s="";

    float getDistance(MotionEvent e) {
         float dx = e.getX(1) - e.getX(0); //index
         float dy = e.getY(1) - e.getY(0);
         return (float) Math.sqrt(dx*dx + dy*dy);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        iv = (ImageView) findViewById(R.id.image);
        tv = (TextView) findViewById(R.id.text);

    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        int act = event.getAction() & 0xff;
        if ( event.getPointerCount() == 2 ){
            switch ( act ){
                case MotionEvent.ACTION_POINTER_DOWN:
                    d1 = getDistance(event);
                    break;
                case MotionEvent.ACTION_MOVE:
                case MotionEvent.ACTION_POINTER_UP:
                    d2 = getDistance(event);
                    ratio = d2/d1;
                    m = new Matrix();
                    m.postScale(ratio, ratio);
                    iv.setImageMatrix(m);
                    s = String.format("d1=%3.0f d2=%3.0f ratio=%4.1f x0=%3.0f y0=%3.0f x1=%3.0f y1=%3.0f",d1,d2,ratio, event.getX(0), event.getY(0), event.getX(1), event.getY(1));
                    tv.setText(s);
                    break;
            }
        }
        return true;
    }
}